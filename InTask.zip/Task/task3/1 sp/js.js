var array = [];
for (var i = 0; i < 10; i++) {
    array.push(
        (function(k) {
            return function() {
                console.log(k);
            };
        })(i)
    );
}
array.forEach(function (element) {
    element();
});
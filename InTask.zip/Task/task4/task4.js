// Mozna na 3 sposoby zrobic

// 1 sposub 
var array = [];
for (var i = 0; i < 10; i++) {
    array.push(
        (function (k) {
            console.log(k);
        })(i)
    );
}
array.forEach(function (element) {
    element;
});

// 2 sposub

var array = [];
for (var i = 0; i < 10; i++) {
    array.push(
        (function (k) {
            return function () {
                console.log(k);
            };
        })(i)
    );
}
array.forEach(function (element) {
    element();
});

// 3 sposub
var array = [];

for (let i = 0; i < 10; i++) {
    array.push(function () {
        console.log(i);
    });
}

array.forEach(function (element) {
    element();
});